﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookStore
{
    public partial class TakeABook : Form
    {
        Controller controllerObj;
        DataTable dtOriginal;
        string ID;
        string username;
        string BookDonater;
        String ISBN;
        int ChosenCount;
        public TakeABook(string name, string Doner, string ISN)
        {
            InitializeComponent();
            controllerObj = new Controller();
            username = name;
            ISBN = ISN;
            BookDonater = Doner;
            DataTable dt = controllerObj.CompanyCity();
            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "city";
            dataGridView1.Visible = false;
            DataTable dtCount = controllerObj.SelectDonateCountD(ISN, Doner);
            string count = dtCount.Rows[0][0].ToString();
            int cnt = 0;
            Int32.TryParse(count, out cnt);
            for (int j = cnt; j > 0; j--)
            {
                comboBox2.Items.Add(j);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (this.comboBox1.SelectedIndex == -1)
            {
                panel5.Visible = true;
            }
            else
            {
                panel5.Visible = false;
                dtOriginal = controllerObj.SelectCompanyCity(comboBox1.Text);
                DataTable dt = dtOriginal;
                dt.Columns.Remove(dt.Columns[3]);
                dataGridView1.Visible = true;
                label1.Visible = true;
                dataGridView1.DataSource = dt;
                dataGridView1.Refresh();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
            var senderGrid = (DataGridView)sender;
            if (senderGrid.Columns[e.ColumnIndex] is DataGridViewButtonColumn &&
                e.RowIndex >= 0)
            {
                ID = dtOriginal.Rows[e.RowIndex][3].ToString();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (this.comboBox2.SelectedIndex == -1)
                panel4.Visible = true;
            else
            {
                panel4.Visible = false;
                Int32.TryParse(comboBox2.Text, out ChosenCount);
                if (ID == "")
                {
                    controllerObj.InsertTakeNoShipping(ISBN, BookDonater, username, ChosenCount);
                }
                else
                {
                    controllerObj.InsertTakeShipping(ISBN, BookDonater, username, ID, ChosenCount);
                }
                controllerObj.decCountDonate(ChosenCount);
            }
        }
    }
}
