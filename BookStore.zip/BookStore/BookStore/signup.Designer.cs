﻿
namespace BookStore
{
    partial class signup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(signup));
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.signupbutton = new System.Windows.Forms.Button();
            this.logo = new System.Windows.Forms.Panel();
            this.panel28 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.loginlogo = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel34 = new System.Windows.Forms.Panel();
            this.panel35 = new System.Windows.Forms.Panel();
            this.countrycodetextBox = new System.Windows.Forms.TextBox();
            this.phonenumbertextBox = new System.Windows.Forms.TextBox();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.postalnumbertextBox = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.usernametextbox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.passwordtextBox = new System.Windows.Forms.TextBox();
            this.panel13 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.emailtextBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.panel29 = new System.Windows.Forms.Panel();
            this.panel30 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.panel31 = new System.Windows.Forms.Panel();
            this.panel32 = new System.Windows.Forms.Panel();
            this.panel33 = new System.Windows.Forms.Panel();
            this.lastnametextBox = new System.Windows.Forms.TextBox();
            this.firstnametextBox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.panel22 = new System.Windows.Forms.Panel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.panel24 = new System.Windows.Forms.Panel();
            this.panel25 = new System.Windows.Forms.Panel();
            this.panel23 = new System.Windows.Forms.Panel();
            this.districttextBox = new System.Windows.Forms.TextBox();
            this.streettextBox = new System.Windows.Forms.TextBox();
            this.citytextBox = new System.Windows.Forms.TextBox();
            this.housenumbertextBox = new System.Windows.Forms.TextBox();
            this.statetextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.logo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.loginlogo.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel29.SuspendLayout();
            this.panel30.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel26.SuspendLayout();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(15, 80);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(203, 31);
            this.label6.TabIndex = 1;
            this.label6.Text = "BOOK STORE";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(653, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Sign Up";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.LinkColor = System.Drawing.Color.White;
            this.linkLabel2.Location = new System.Drawing.Point(645, 488);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(110, 13);
            this.linkLabel2.TabIndex = 9;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "already have account";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // signupbutton
            // 
            this.signupbutton.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.signupbutton.FlatAppearance.BorderSize = 2;
            this.signupbutton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.signupbutton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.signupbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.signupbutton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.signupbutton.Location = new System.Drawing.Point(614, 452);
            this.signupbutton.Name = "signupbutton";
            this.signupbutton.Size = new System.Drawing.Size(191, 32);
            this.signupbutton.TabIndex = 5;
            this.signupbutton.Text = "Sign Up";
            this.signupbutton.UseVisualStyleBackColor = true;
            this.signupbutton.Click += new System.EventHandler(this.loginbutton_Click);
            // 
            // logo
            // 
            this.logo.BackColor = System.Drawing.Color.Bisque;
            this.logo.Controls.Add(this.panel28);
            this.logo.Controls.Add(this.label6);
            this.logo.Controls.Add(this.pictureBox3);
            this.logo.Dock = System.Windows.Forms.DockStyle.Left;
            this.logo.Location = new System.Drawing.Point(0, 35);
            this.logo.Name = "logo";
            this.logo.Size = new System.Drawing.Size(224, 475);
            this.logo.TabIndex = 15;
            this.logo.Paint += new System.Windows.Forms.PaintEventHandler(this.logo_Paint);
            // 
            // panel28
            // 
            this.panel28.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel28.Location = new System.Drawing.Point(0, 0);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(224, 55);
            this.panel28.TabIndex = 18;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(0, 114);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(234, 179);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Bisque;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1082, 35);
            this.panel1.TabIndex = 14;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // loginlogo
            // 
            this.loginlogo.Controls.Add(this.panel18);
            this.loginlogo.Controls.Add(this.panel14);
            this.loginlogo.Controls.Add(this.panel4);
            this.loginlogo.Controls.Add(this.label10);
            this.loginlogo.Controls.Add(this.label9);
            this.loginlogo.Controls.Add(this.label2);
            this.loginlogo.Controls.Add(this.panel6);
            this.loginlogo.Controls.Add(this.label14);
            this.loginlogo.Controls.Add(this.panel7);
            this.loginlogo.Controls.Add(this.label8);
            this.loginlogo.Controls.Add(this.label13);
            this.loginlogo.Controls.Add(this.panel29);
            this.loginlogo.Controls.Add(this.label11);
            this.loginlogo.Controls.Add(this.panel21);
            this.loginlogo.Controls.Add(this.label4);
            this.loginlogo.Controls.Add(this.linkLabel2);
            this.loginlogo.Controls.Add(this.signupbutton);
            this.loginlogo.Controls.Add(this.label1);
            this.loginlogo.Location = new System.Drawing.Point(0, 0);
            this.loginlogo.Name = "loginlogo";
            this.loginlogo.Size = new System.Drawing.Size(1079, 510);
            this.loginlogo.TabIndex = 16;
            this.loginlogo.Paint += new System.Windows.Forms.PaintEventHandler(this.loginlogo_Paint);
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.panel19);
            this.panel18.Controls.Add(this.panel20);
            this.panel18.Location = new System.Drawing.Point(333, 351);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(316, 95);
            this.panel18.TabIndex = 32;
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.label16);
            this.panel19.Location = new System.Drawing.Point(3, 61);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(310, 25);
            this.panel19.TabIndex = 4;
            this.panel19.Visible = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Red;
            this.label16.Location = new System.Drawing.Point(3, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(118, 17);
            this.label16.TabIndex = 2;
            this.label16.Text = "Enter your phone";
            // 
            // panel20
            // 
            this.panel20.Controls.Add(this.panel34);
            this.panel20.Controls.Add(this.panel35);
            this.panel20.Controls.Add(this.countrycodetextBox);
            this.panel20.Controls.Add(this.phonenumbertextBox);
            this.panel20.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel20.Location = new System.Drawing.Point(0, 0);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(316, 55);
            this.panel20.TabIndex = 3;
            this.panel20.Click += new System.EventHandler(this.panel20_Click);
            // 
            // panel34
            // 
            this.panel34.BackColor = System.Drawing.Color.White;
            this.panel34.Location = new System.Drawing.Point(10, 42);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(110, 3);
            this.panel34.TabIndex = 12;
            // 
            // panel35
            // 
            this.panel35.BackColor = System.Drawing.Color.White;
            this.panel35.Location = new System.Drawing.Point(130, 42);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(180, 3);
            this.panel35.TabIndex = 12;
            // 
            // countrycodetextBox
            // 
            this.countrycodetextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.countrycodetextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.countrycodetextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.countrycodetextBox.ForeColor = System.Drawing.Color.Gray;
            this.countrycodetextBox.Location = new System.Drawing.Point(10, 5);
            this.countrycodetextBox.Name = "countrycodetextBox";
            this.countrycodetextBox.Size = new System.Drawing.Size(114, 19);
            this.countrycodetextBox.TabIndex = 2;
            this.countrycodetextBox.Text = "Country Code";
            this.countrycodetextBox.Click += new System.EventHandler(this.countrycodetextBox_Click_1);
            this.countrycodetextBox.TextChanged += new System.EventHandler(this.countrycodetextBox_TextChanged_1);
            // 
            // phonenumbertextBox
            // 
            this.phonenumbertextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.phonenumbertextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.phonenumbertextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phonenumbertextBox.ForeColor = System.Drawing.Color.Gray;
            this.phonenumbertextBox.Location = new System.Drawing.Point(130, 5);
            this.phonenumbertextBox.Name = "phonenumbertextBox";
            this.phonenumbertextBox.Size = new System.Drawing.Size(180, 19);
            this.phonenumbertextBox.TabIndex = 5;
            this.phonenumbertextBox.Text = "Phone Number";
            this.phonenumbertextBox.Click += new System.EventHandler(this.phonenumbertextBox_Click_1);
            this.phonenumbertextBox.TextChanged += new System.EventHandler(this.phonenumbertextBox_TextChanged_1);
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.panel15);
            this.panel14.Controls.Add(this.panel16);
            this.panel14.Location = new System.Drawing.Point(333, 259);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(316, 95);
            this.panel14.TabIndex = 31;
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.label15);
            this.panel15.Location = new System.Drawing.Point(3, 61);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(310, 25);
            this.panel15.TabIndex = 4;
            this.panel15.Visible = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Red;
            this.label15.Location = new System.Drawing.Point(3, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(168, 17);
            this.label15.TabIndex = 2;
            this.label15.Text = "Enter your postal number";
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.panel17);
            this.panel16.Controls.Add(this.postalnumbertextBox);
            this.panel16.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel16.Location = new System.Drawing.Point(0, 0);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(316, 55);
            this.panel16.TabIndex = 3;
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.White;
            this.panel17.Location = new System.Drawing.Point(9, 45);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(301, 3);
            this.panel17.TabIndex = 4;
            // 
            // postalnumbertextBox
            // 
            this.postalnumbertextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.postalnumbertextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.postalnumbertextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.postalnumbertextBox.ForeColor = System.Drawing.Color.Gray;
            this.postalnumbertextBox.Location = new System.Drawing.Point(6, 14);
            this.postalnumbertextBox.Name = "postalnumbertextBox";
            this.postalnumbertextBox.Size = new System.Drawing.Size(301, 19);
            this.postalnumbertextBox.TabIndex = 2;
            this.postalnumbertextBox.Text = "Postal Number";
            this.postalnumbertextBox.Click += new System.EventHandler(this.postalnumbertextBox_Click);
            this.postalnumbertextBox.TextChanged += new System.EventHandler(this.postalnumbertextBox_TextChanged);
            this.postalnumbertextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.postalnumbertextBox_KeyPress);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Controls.Add(this.panel2);
            this.panel4.Location = new System.Drawing.Point(758, 65);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(316, 95);
            this.panel4.TabIndex = 30;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.label3);
            this.panel5.Location = new System.Drawing.Point(3, 61);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(310, 25);
            this.panel5.TabIndex = 4;
            this.panel5.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(3, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(182, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "In valid user name try again";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.usernametextbox);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(316, 55);
            this.panel2.TabIndex = 3;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Location = new System.Drawing.Point(9, 45);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(301, 3);
            this.panel3.TabIndex = 4;
            // 
            // usernametextbox
            // 
            this.usernametextbox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.usernametextbox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.usernametextbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usernametextbox.ForeColor = System.Drawing.Color.Gray;
            this.usernametextbox.Location = new System.Drawing.Point(9, 9);
            this.usernametextbox.Name = "usernametextbox";
            this.usernametextbox.Size = new System.Drawing.Size(301, 19);
            this.usernametextbox.TabIndex = 2;
            this.usernametextbox.Text = "Enter User name";
            this.usernametextbox.Click += new System.EventHandler(this.usernametextbox_Click_1);
            this.usernametextbox.TextChanged += new System.EventHandler(this.usernametextbox_TextChanged_1);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(251, 369);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(49, 17);
            this.label10.TabIndex = 17;
            this.label10.Text = "Phone";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(228, 273);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(99, 17);
            this.label9.TabIndex = 15;
            this.label9.Text = "Postal number";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(676, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 17);
            this.label2.TabIndex = 29;
            this.label2.Text = "User Name";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.panel8);
            this.panel6.Controls.Add(this.panel9);
            this.panel6.Location = new System.Drawing.Point(757, 163);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(316, 95);
            this.panel6.TabIndex = 28;
            this.panel6.Paint += new System.Windows.Forms.PaintEventHandler(this.panel6_Paint);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.label5);
            this.panel8.Location = new System.Drawing.Point(3, 61);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(310, 25);
            this.panel8.TabIndex = 4;
            this.panel8.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(3, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(168, 17);
            this.label5.TabIndex = 2;
            this.label5.Text = "You must enter password";
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.passwordtextBox);
            this.panel9.Controls.Add(this.panel13);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel9.Location = new System.Drawing.Point(0, 0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(316, 58);
            this.panel9.TabIndex = 3;
            // 
            // passwordtextBox
            // 
            this.passwordtextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.passwordtextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.passwordtextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordtextBox.ForeColor = System.Drawing.Color.Gray;
            this.passwordtextBox.Location = new System.Drawing.Point(9, 15);
            this.passwordtextBox.Name = "passwordtextBox";
            this.passwordtextBox.Size = new System.Drawing.Size(301, 19);
            this.passwordtextBox.TabIndex = 27;
            this.passwordtextBox.Text = "Password";
            this.passwordtextBox.Click += new System.EventHandler(this.passwordtextBox_Click);
            this.passwordtextBox.TextChanged += new System.EventHandler(this.passwordtextBox_TextChanged);
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.White;
            this.panel13.Location = new System.Drawing.Point(9, 45);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(301, 3);
            this.panel13.TabIndex = 4;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(676, 178);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(69, 17);
            this.label14.TabIndex = 27;
            this.label14.Text = "Password";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.panel10);
            this.panel7.Controls.Add(this.panel11);
            this.panel7.Location = new System.Drawing.Point(333, 162);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(316, 95);
            this.panel7.TabIndex = 26;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.label7);
            this.panel10.Location = new System.Drawing.Point(3, 61);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(310, 25);
            this.panel10.TabIndex = 4;
            this.panel10.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(3, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(183, 17);
            this.label7.TabIndex = 2;
            this.label7.Text = "Enter your E-mail to sign up";
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.panel12);
            this.panel11.Controls.Add(this.emailtextBox);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel11.Location = new System.Drawing.Point(0, 0);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(316, 55);
            this.panel11.TabIndex = 3;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.White;
            this.panel12.Location = new System.Drawing.Point(9, 45);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(301, 3);
            this.panel12.TabIndex = 4;
            // 
            // emailtextBox
            // 
            this.emailtextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.emailtextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.emailtextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailtextBox.ForeColor = System.Drawing.Color.Gray;
            this.emailtextBox.Location = new System.Drawing.Point(9, 16);
            this.emailtextBox.Name = "emailtextBox";
            this.emailtextBox.Size = new System.Drawing.Size(301, 19);
            this.emailtextBox.TabIndex = 24;
            this.emailtextBox.Text = "E-mail";
            this.emailtextBox.Click += new System.EventHandler(this.emailtextBox_Click);
            this.emailtextBox.TextChanged += new System.EventHandler(this.emailtextBox_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(251, 181);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 17);
            this.label8.TabIndex = 25;
            this.label8.Text = "E-mail";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(251, 84);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(71, 17);
            this.label13.TabIndex = 23;
            this.label13.Text = "Full Name";
            // 
            // panel29
            // 
            this.panel29.Controls.Add(this.panel30);
            this.panel29.Controls.Add(this.panel31);
            this.panel29.Location = new System.Drawing.Point(334, 65);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(316, 95);
            this.panel29.TabIndex = 22;
            // 
            // panel30
            // 
            this.panel30.Controls.Add(this.label12);
            this.panel30.Location = new System.Drawing.Point(3, 61);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(310, 25);
            this.panel30.TabIndex = 4;
            this.panel30.Visible = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(3, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(201, 17);
            this.label12.TabIndex = 2;
            this.label12.Text = "Enter your full name to sign up";
            // 
            // panel31
            // 
            this.panel31.Controls.Add(this.panel32);
            this.panel31.Controls.Add(this.panel33);
            this.panel31.Controls.Add(this.lastnametextBox);
            this.panel31.Controls.Add(this.firstnametextBox);
            this.panel31.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel31.Location = new System.Drawing.Point(0, 0);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(316, 55);
            this.panel31.TabIndex = 3;
            this.panel31.Paint += new System.Windows.Forms.PaintEventHandler(this.panel31_Paint);
            // 
            // panel32
            // 
            this.panel32.BackColor = System.Drawing.Color.White;
            this.panel32.Location = new System.Drawing.Point(145, 44);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(160, 3);
            this.panel32.TabIndex = 16;
            // 
            // panel33
            // 
            this.panel33.BackColor = System.Drawing.Color.White;
            this.panel33.Location = new System.Drawing.Point(5, 44);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(130, 3);
            this.panel33.TabIndex = 17;
            // 
            // lastnametextBox
            // 
            this.lastnametextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lastnametextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lastnametextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastnametextBox.ForeColor = System.Drawing.Color.Gray;
            this.lastnametextBox.Location = new System.Drawing.Point(161, 7);
            this.lastnametextBox.Name = "lastnametextBox";
            this.lastnametextBox.Size = new System.Drawing.Size(150, 19);
            this.lastnametextBox.TabIndex = 15;
            this.lastnametextBox.Text = "Last Name";
            this.lastnametextBox.Click += new System.EventHandler(this.lastnametextBox_Click);
            this.lastnametextBox.TextChanged += new System.EventHandler(this.lastnametextBox_TextChanged);
            // 
            // firstnametextBox
            // 
            this.firstnametextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.firstnametextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.firstnametextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstnametextBox.ForeColor = System.Drawing.Color.Gray;
            this.firstnametextBox.Location = new System.Drawing.Point(5, 7);
            this.firstnametextBox.Name = "firstnametextBox";
            this.firstnametextBox.Size = new System.Drawing.Size(150, 19);
            this.firstnametextBox.TabIndex = 14;
            this.firstnametextBox.Text = "First Name";
            this.firstnametextBox.Click += new System.EventHandler(this.firstnametextBox_Click);
            this.firstnametextBox.TextChanged += new System.EventHandler(this.firstnametextBox_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(676, 284);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(60, 17);
            this.label11.TabIndex = 20;
            this.label11.Text = "Address";
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.panel26);
            this.panel21.Controls.Add(this.panel22);
            this.panel21.Controls.Add(this.panel27);
            this.panel21.Controls.Add(this.panel24);
            this.panel21.Controls.Add(this.panel25);
            this.panel21.Controls.Add(this.panel23);
            this.panel21.Controls.Add(this.districttextBox);
            this.panel21.Controls.Add(this.streettextBox);
            this.panel21.Controls.Add(this.citytextBox);
            this.panel21.Controls.Add(this.housenumbertextBox);
            this.panel21.Controls.Add(this.statetextBox);
            this.panel21.Location = new System.Drawing.Point(757, 269);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(316, 137);
            this.panel21.TabIndex = 19;
            this.panel21.Paint += new System.Windows.Forms.PaintEventHandler(this.panel21_Paint_1);
            // 
            // panel26
            // 
            this.panel26.Controls.Add(this.label17);
            this.panel26.Location = new System.Drawing.Point(4, 109);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(310, 25);
            this.panel26.TabIndex = 33;
            this.panel26.Visible = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Red;
            this.label17.Location = new System.Drawing.Point(3, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(151, 17);
            this.label17.TabIndex = 2;
            this.label17.Text = "Enter your full address";
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.Color.White;
            this.panel22.Location = new System.Drawing.Point(143, 32);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(160, 3);
            this.panel22.TabIndex = 13;
            // 
            // panel27
            // 
            this.panel27.BackColor = System.Drawing.Color.White;
            this.panel27.Location = new System.Drawing.Point(3, 32);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(130, 3);
            this.panel27.TabIndex = 14;
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.Color.White;
            this.panel24.Location = new System.Drawing.Point(3, 100);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(130, 3);
            this.panel24.TabIndex = 12;
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.Color.White;
            this.panel25.Location = new System.Drawing.Point(143, 66);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(160, 3);
            this.panel25.TabIndex = 11;
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.Color.White;
            this.panel23.Location = new System.Drawing.Point(3, 66);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(130, 3);
            this.panel23.TabIndex = 11;
            // 
            // districttextBox
            // 
            this.districttextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.districttextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.districttextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.districttextBox.ForeColor = System.Drawing.Color.Gray;
            this.districttextBox.Location = new System.Drawing.Point(143, 41);
            this.districttextBox.Name = "districttextBox";
            this.districttextBox.Size = new System.Drawing.Size(145, 19);
            this.districttextBox.TabIndex = 9;
            this.districttextBox.Text = "Disrtict";
            this.districttextBox.Click += new System.EventHandler(this.districttextBox_Click);
            this.districttextBox.TextChanged += new System.EventHandler(this.districttextBox_TextChanged);
            // 
            // streettextBox
            // 
            this.streettextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.streettextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.streettextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.streettextBox.ForeColor = System.Drawing.Color.Gray;
            this.streettextBox.Location = new System.Drawing.Point(2, 41);
            this.streettextBox.Name = "streettextBox";
            this.streettextBox.Size = new System.Drawing.Size(145, 19);
            this.streettextBox.TabIndex = 6;
            this.streettextBox.Text = "Street";
            this.streettextBox.Click += new System.EventHandler(this.streettextBox_Click);
            this.streettextBox.TextChanged += new System.EventHandler(this.streettextBox_TextChanged);
            // 
            // citytextBox
            // 
            this.citytextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.citytextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.citytextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.citytextBox.ForeColor = System.Drawing.Color.Gray;
            this.citytextBox.Location = new System.Drawing.Point(153, 4);
            this.citytextBox.Name = "citytextBox";
            this.citytextBox.Size = new System.Drawing.Size(150, 19);
            this.citytextBox.TabIndex = 5;
            this.citytextBox.Text = "City";
            this.citytextBox.Click += new System.EventHandler(this.citytextBox_Click);
            this.citytextBox.TextChanged += new System.EventHandler(this.citytextBox_TextChanged);
            // 
            // housenumbertextBox
            // 
            this.housenumbertextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.housenumbertextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.housenumbertextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.housenumbertextBox.ForeColor = System.Drawing.Color.Gray;
            this.housenumbertextBox.Location = new System.Drawing.Point(3, 75);
            this.housenumbertextBox.Name = "housenumbertextBox";
            this.housenumbertextBox.Size = new System.Drawing.Size(150, 19);
            this.housenumbertextBox.TabIndex = 4;
            this.housenumbertextBox.Text = "House Number";
            this.housenumbertextBox.Click += new System.EventHandler(this.housenumbertextBox_Click);
            this.housenumbertextBox.TextChanged += new System.EventHandler(this.housenumbertextBox_TextChanged_1);
            this.housenumbertextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.housenumbertextBox_KeyPress_1);
            // 
            // statetextBox
            // 
            this.statetextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.statetextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.statetextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statetextBox.ForeColor = System.Drawing.Color.Gray;
            this.statetextBox.Location = new System.Drawing.Point(2, 4);
            this.statetextBox.Name = "statetextBox";
            this.statetextBox.Size = new System.Drawing.Size(150, 19);
            this.statetextBox.TabIndex = 3;
            this.statetextBox.Text = "state";
            this.statetextBox.Click += new System.EventHandler(this.statetextBox_Click);
            this.statetextBox.TextChanged += new System.EventHandler(this.statetextBox_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(0, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "label4";
            // 
            // signup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.ClientSize = new System.Drawing.Size(1082, 510);
            this.Controls.Add(this.logo);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.loginlogo);
            this.Name = "signup";
            this.Text = "Sign Up";
            this.Load += new System.EventHandler(this.signup_Load);
            this.logo.ResumeLayout(false);
            this.logo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.loginlogo.ResumeLayout(false);
            this.loginlogo.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel29.ResumeLayout(false);
            this.panel30.ResumeLayout(false);
            this.panel30.PerformLayout();
            this.panel31.ResumeLayout(false);
            this.panel31.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.panel26.ResumeLayout(false);
            this.panel26.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.Button signupbutton;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel logo;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel loginlogo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox postalnumbertextBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.TextBox streettextBox;
        private System.Windows.Forms.TextBox citytextBox;
        private System.Windows.Forms.TextBox housenumbertextBox;
        private System.Windows.Forms.TextBox statetextBox;
        private System.Windows.Forms.TextBox districttextBox;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox emailtextBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.TextBox lastnametextBox;
        private System.Windows.Forms.TextBox firstnametextBox;
        private System.Windows.Forms.TextBox passwordtextBox;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox usernametextbox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.TextBox countrycodetextBox;
        private System.Windows.Forms.TextBox phonenumbertextBox;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Label label17;
    }
}