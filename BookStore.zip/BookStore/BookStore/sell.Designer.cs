﻿namespace BookStore
{
    partial class sell
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PleaseEnterThisInformations = new System.Windows.Forms.Label();
            this.BookTitle = new System.Windows.Forms.Label();
            this.BookCover = new System.Windows.Forms.Label();
            this.ISPN = new System.Windows.Forms.Label();
            this.BookCategory = new System.Windows.Forms.Label();
            this.NumberofBooks = new System.Windows.Forms.Label();
            this.NumberofBookPages = new System.Windows.Forms.Label();
            this.InformationsabouttheBook = new System.Windows.Forms.Label();
            this.BookLanguage = new System.Windows.Forms.Label();
            this.NumberofEdition = new System.Windows.Forms.Label();
            this.PriceofaBook = new System.Windows.Forms.Label();
            this.PublishingDate = new System.Windows.Forms.Label();
            this.SNatB = new System.Windows.Forms.TextBox();
            this.SNoE = new System.Windows.Forms.TextBox();
            this.SBookLanguage = new System.Windows.Forms.TextBox();
            this.SNumberofBookPages = new System.Windows.Forms.TextBox();
            this.SNumberofBooks = new System.Windows.Forms.TextBox();
            this.SBookCategory = new System.Windows.Forms.TextBox();
            this.SISPN = new System.Windows.Forms.TextBox();
            this.SBookTitle = new System.Windows.Forms.TextBox();
            this.SPoaB = new System.Windows.Forms.TextBox();
            this.SInsertAuthorInformation = new System.Windows.Forms.Button();
            this.SpictureBox1 = new System.Windows.Forms.PictureBox();
            this.SUploadBookCover = new System.Windows.Forms.Button();
            this.SPD = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.SpictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // PleaseEnterThisInformations
            // 
            this.PleaseEnterThisInformations.AutoSize = true;
            this.PleaseEnterThisInformations.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PleaseEnterThisInformations.Location = new System.Drawing.Point(11, 9);
            this.PleaseEnterThisInformations.Name = "PleaseEnterThisInformations";
            this.PleaseEnterThisInformations.Size = new System.Drawing.Size(241, 23);
            this.PleaseEnterThisInformations.TabIndex = 0;
            this.PleaseEnterThisInformations.Text = "Please Enter This Informations";
            this.PleaseEnterThisInformations.Click += new System.EventHandler(this.label1_Click);
            // 
            // BookTitle
            // 
            this.BookTitle.AutoSize = true;
            this.BookTitle.Location = new System.Drawing.Point(12, 60);
            this.BookTitle.Name = "BookTitle";
            this.BookTitle.Size = new System.Drawing.Size(55, 13);
            this.BookTitle.TabIndex = 1;
            this.BookTitle.Text = "Book Title";
            // 
            // BookCover
            // 
            this.BookCover.AutoSize = true;
            this.BookCover.Location = new System.Drawing.Point(359, 60);
            this.BookCover.Name = "BookCover";
            this.BookCover.Size = new System.Drawing.Size(63, 13);
            this.BookCover.TabIndex = 2;
            this.BookCover.Text = "Book Cover";
            // 
            // ISPN
            // 
            this.ISPN.AutoSize = true;
            this.ISPN.Location = new System.Drawing.Point(12, 150);
            this.ISPN.Name = "ISPN";
            this.ISPN.Size = new System.Drawing.Size(32, 13);
            this.ISPN.TabIndex = 3;
            this.ISPN.Text = "ISPN";
            // 
            // BookCategory
            // 
            this.BookCategory.AutoSize = true;
            this.BookCategory.Location = new System.Drawing.Point(12, 200);
            this.BookCategory.Name = "BookCategory";
            this.BookCategory.Size = new System.Drawing.Size(77, 13);
            this.BookCategory.TabIndex = 4;
            this.BookCategory.Text = "Book Category";
            // 
            // NumberofBooks
            // 
            this.NumberofBooks.AutoSize = true;
            this.NumberofBooks.Location = new System.Drawing.Point(12, 246);
            this.NumberofBooks.Name = "NumberofBooks";
            this.NumberofBooks.Size = new System.Drawing.Size(89, 13);
            this.NumberofBooks.TabIndex = 5;
            this.NumberofBooks.Text = "Number of Books";
            // 
            // NumberofBookPages
            // 
            this.NumberofBookPages.AutoSize = true;
            this.NumberofBookPages.Location = new System.Drawing.Point(9, 295);
            this.NumberofBookPages.Name = "NumberofBookPages";
            this.NumberofBookPages.Size = new System.Drawing.Size(117, 13);
            this.NumberofBookPages.TabIndex = 6;
            this.NumberofBookPages.Text = "Number of Book Pages";
            // 
            // InformationsabouttheBook
            // 
            this.InformationsabouttheBook.AutoSize = true;
            this.InformationsabouttheBook.Location = new System.Drawing.Point(185, 60);
            this.InformationsabouttheBook.Name = "InformationsabouttheBook";
            this.InformationsabouttheBook.Size = new System.Drawing.Size(140, 13);
            this.InformationsabouttheBook.TabIndex = 7;
            this.InformationsabouttheBook.Text = "Informations about the Book";
            // 
            // BookLanguage
            // 
            this.BookLanguage.AutoSize = true;
            this.BookLanguage.Location = new System.Drawing.Point(185, 105);
            this.BookLanguage.Name = "BookLanguage";
            this.BookLanguage.Size = new System.Drawing.Size(83, 13);
            this.BookLanguage.TabIndex = 8;
            this.BookLanguage.Text = "Book Language";
            // 
            // NumberofEdition
            // 
            this.NumberofEdition.AutoSize = true;
            this.NumberofEdition.Location = new System.Drawing.Point(185, 151);
            this.NumberofEdition.Name = "NumberofEdition";
            this.NumberofEdition.Size = new System.Drawing.Size(91, 13);
            this.NumberofEdition.TabIndex = 9;
            this.NumberofEdition.Text = "Number of Edition";
            // 
            // PriceofaBook
            // 
            this.PriceofaBook.AutoSize = true;
            this.PriceofaBook.Location = new System.Drawing.Point(12, 105);
            this.PriceofaBook.Name = "PriceofaBook";
            this.PriceofaBook.Size = new System.Drawing.Size(80, 13);
            this.PriceofaBook.TabIndex = 10;
            this.PriceofaBook.Text = "Price of a Book";
            // 
            // PublishingDate
            // 
            this.PublishingDate.AutoSize = true;
            this.PublishingDate.Location = new System.Drawing.Point(185, 246);
            this.PublishingDate.Name = "PublishingDate";
            this.PublishingDate.Size = new System.Drawing.Size(81, 13);
            this.PublishingDate.TabIndex = 12;
            this.PublishingDate.Text = "Publishing Date";
            // 
            // SNatB
            // 
            this.SNatB.Location = new System.Drawing.Point(188, 76);
            this.SNatB.Name = "SNatB";
            this.SNatB.Size = new System.Drawing.Size(100, 20);
            this.SNatB.TabIndex = 13;
            this.SNatB.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // SNoE
            // 
            this.SNoE.Location = new System.Drawing.Point(188, 167);
            this.SNoE.Name = "SNoE";
            this.SNoE.Size = new System.Drawing.Size(100, 20);
            this.SNoE.TabIndex = 14;
            // 
            // SBookLanguage
            // 
            this.SBookLanguage.Location = new System.Drawing.Point(188, 121);
            this.SBookLanguage.Name = "SBookLanguage";
            this.SBookLanguage.Size = new System.Drawing.Size(100, 20);
            this.SBookLanguage.TabIndex = 15;
            // 
            // SNumberofBookPages
            // 
            this.SNumberofBookPages.Location = new System.Drawing.Point(12, 311);
            this.SNumberofBookPages.Name = "SNumberofBookPages";
            this.SNumberofBookPages.Size = new System.Drawing.Size(100, 20);
            this.SNumberofBookPages.TabIndex = 16;
            // 
            // SNumberofBooks
            // 
            this.SNumberofBooks.Location = new System.Drawing.Point(12, 262);
            this.SNumberofBooks.Name = "SNumberofBooks";
            this.SNumberofBooks.Size = new System.Drawing.Size(100, 20);
            this.SNumberofBooks.TabIndex = 17;
            // 
            // SBookCategory
            // 
            this.SBookCategory.Location = new System.Drawing.Point(12, 216);
            this.SBookCategory.Name = "SBookCategory";
            this.SBookCategory.Size = new System.Drawing.Size(100, 20);
            this.SBookCategory.TabIndex = 18;
            // 
            // SISPN
            // 
            this.SISPN.Location = new System.Drawing.Point(12, 167);
            this.SISPN.Name = "SISPN";
            this.SISPN.Size = new System.Drawing.Size(100, 20);
            this.SISPN.TabIndex = 19;
            // 
            // SBookTitle
            // 
            this.SBookTitle.Location = new System.Drawing.Point(12, 76);
            this.SBookTitle.Name = "SBookTitle";
            this.SBookTitle.Size = new System.Drawing.Size(100, 20);
            this.SBookTitle.TabIndex = 21;
            this.SBookTitle.TextChanged += new System.EventHandler(this.SBookTitle_TextChanged);
            // 
            // SPoaB
            // 
            this.SPoaB.Location = new System.Drawing.Point(10, 121);
            this.SPoaB.Name = "SPoaB";
            this.SPoaB.Size = new System.Drawing.Size(100, 20);
            this.SPoaB.TabIndex = 22;
            // 
            // SInsertAuthorInformation
            // 
            this.SInsertAuthorInformation.Location = new System.Drawing.Point(188, 311);
            this.SInsertAuthorInformation.Name = "SInsertAuthorInformation";
            this.SInsertAuthorInformation.Size = new System.Drawing.Size(150, 23);
            this.SInsertAuthorInformation.TabIndex = 25;
            this.SInsertAuthorInformation.Text = "Insert Author Information";
            this.SInsertAuthorInformation.UseVisualStyleBackColor = true;
            this.SInsertAuthorInformation.Click += new System.EventHandler(this.button1_Click);
            // 
            // SpictureBox1
            // 
            this.SpictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SpictureBox1.Location = new System.Drawing.Point(362, 76);
            this.SpictureBox1.Name = "SpictureBox1";
            this.SpictureBox1.Size = new System.Drawing.Size(127, 111);
            this.SpictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.SpictureBox1.TabIndex = 26;
            this.SpictureBox1.TabStop = false;
            // 
            // SUploadBookCover
            // 
            this.SUploadBookCover.Location = new System.Drawing.Point(362, 213);
            this.SUploadBookCover.Name = "SUploadBookCover";
            this.SUploadBookCover.Size = new System.Drawing.Size(127, 23);
            this.SUploadBookCover.TabIndex = 27;
            this.SUploadBookCover.Text = "Upload Book Cover";
            this.SUploadBookCover.UseVisualStyleBackColor = true;
            this.SUploadBookCover.Click += new System.EventHandler(this.SUploadBookCover_Click);
            // 
            // SPD
            // 
            this.SPD.Location = new System.Drawing.Point(188, 262);
            this.SPD.Name = "SPD";
            this.SPD.Size = new System.Drawing.Size(200, 20);
            this.SPD.TabIndex = 28;
            // 
            // sell
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(528, 382);
            this.Controls.Add(this.SPD);
            this.Controls.Add(this.SUploadBookCover);
            this.Controls.Add(this.SpictureBox1);
            this.Controls.Add(this.SInsertAuthorInformation);
            this.Controls.Add(this.SPoaB);
            this.Controls.Add(this.SBookTitle);
            this.Controls.Add(this.SISPN);
            this.Controls.Add(this.SBookCategory);
            this.Controls.Add(this.SNumberofBooks);
            this.Controls.Add(this.SNumberofBookPages);
            this.Controls.Add(this.SBookLanguage);
            this.Controls.Add(this.SNoE);
            this.Controls.Add(this.SNatB);
            this.Controls.Add(this.PublishingDate);
            this.Controls.Add(this.PriceofaBook);
            this.Controls.Add(this.NumberofEdition);
            this.Controls.Add(this.BookLanguage);
            this.Controls.Add(this.InformationsabouttheBook);
            this.Controls.Add(this.NumberofBookPages);
            this.Controls.Add(this.NumberofBooks);
            this.Controls.Add(this.BookCategory);
            this.Controls.Add(this.ISPN);
            this.Controls.Add(this.BookCover);
            this.Controls.Add(this.BookTitle);
            this.Controls.Add(this.PleaseEnterThisInformations);
            this.Name = "sell";
            this.Text = "sell";
            ((System.ComponentModel.ISupportInitialize)(this.SpictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label PleaseEnterThisInformations;
        private System.Windows.Forms.Label BookTitle;
        private System.Windows.Forms.Label BookCover;
        private System.Windows.Forms.Label ISPN;
        private System.Windows.Forms.Label BookCategory;
        private System.Windows.Forms.Label NumberofBooks;
        private System.Windows.Forms.Label NumberofBookPages;
        private System.Windows.Forms.Label InformationsabouttheBook;
        private System.Windows.Forms.Label BookLanguage;
        private System.Windows.Forms.Label NumberofEdition;
        private System.Windows.Forms.Label PriceofaBook;
        private System.Windows.Forms.Label PublishingDate;
        private System.Windows.Forms.TextBox SNatB;
        private System.Windows.Forms.TextBox SNoE;
        private System.Windows.Forms.TextBox SBookLanguage;
        private System.Windows.Forms.TextBox SNumberofBookPages;
        private System.Windows.Forms.TextBox SNumberofBooks;
        private System.Windows.Forms.TextBox SBookCategory;
        private System.Windows.Forms.TextBox SISPN;
        private System.Windows.Forms.TextBox SBookTitle;
        private System.Windows.Forms.TextBox SPoaB;
        private System.Windows.Forms.Button SInsertAuthorInformation;
        private System.Windows.Forms.PictureBox SpictureBox1;
        private System.Windows.Forms.Button SUploadBookCover;
        private System.Windows.Forms.DateTimePicker SPD;

    }
}